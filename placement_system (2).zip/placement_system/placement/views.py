from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request,'home.html')


def student_register(request):

    if request.method == "POST":

        email = request.POST['email']

        if User.objects.filter(username=email).exists():
            return render(request,'student.html',{'error':'User exists'})

        user = User.objects.create_user(
            username=email,
            password="1234"
        )

        Student.objects.create(
            user=user,
            name=request.POST['name'],
            email=email,
            phone=request.POST['phone'],
            branch=request.POST['branch'],
            cgpa=request.POST['cgpa'],
            skills=request.POST['skills'],
            resume=request.FILES.get('resume')
        )

        return redirect('/login/')

    return render(request,'student.html')


def login_view(request):

    if request.method=="POST":

        user = authenticate(
            request,
            username=request.POST['username'],
            password=request.POST['password']
        )

        if user:
            login(request,user)
            return redirect('/dashboard/')

    return render(request,'login.html')


def logout_view(request):
    logout(request)
    return redirect('/login/')


@login_required
def dashboard(request):

    student = Student.objects.get(user=request.user)
    jobs = Job.objects.all()

    return render(request,'dashboard.html',{
        'student':student,
        'jobs':jobs
    })


def company_register(request):

    if request.method=="POST":

        Company.objects.create(
            name=request.POST['name'],
            email=request.POST['email'],
            location=request.POST['location'],
            description=request.POST['description']
        )

        return redirect('/')

    return render(request,'company.html')


def add_job(request):

    companies = Company.objects.all()

    if request.method=="POST":

        Job.objects.create(
            company_id=request.POST.get('company'),
            title=request.POST.get('title'),
            description=request.POST.get('description'),
            eligibility_cgpa=request.POST.get('cgpa'),
            skills_required=request.POST.get('skills'),
            deadline=request.POST.get('deadline')
        )

        return redirect('/jobs/')

    return render(request,'job.html',{
        'companies':companies
    })


def view_jobs(request):

    jobs = Job.objects.all()
    return render(request,'jobs.html',{'jobs':jobs})


@login_required
def apply_job(request,id):

    student = Student.objects.get(user=request.user)
    job = Job.objects.get(id=id)

    if not Application.objects.filter(student=student,job=job).exists():

        Application.objects.create(
            student=student,
            job=job
        )

    return redirect('/dashboard/')


def applications(request):

    apps = Application.objects.all()
    return render(request,'applications.html',{'apps':apps})


def shortlist(request,id):

    app = Application.objects.get(id=id)
    app.status = "Shortlisted"
    app.save()

    return redirect('/applications/')


def schedule(request,id):

    app = Application.objects.get(id=id)

    if request.method=="POST":
        app.interview_date = request.POST['date']
        app.save()
        return redirect('/applications/')

    return render(request,'schedule.html',{'app':app})


def publish_result(request,id):

    app = Application.objects.get(id=id)

    if request.method=="POST":

        app.result = request.POST['result']

        if request.FILES.get('offer'):
            app.offer_letter = request.FILES['offer']

        app.save()

        return redirect('/applications/')

    return render(request,'result.html',{'app':app})