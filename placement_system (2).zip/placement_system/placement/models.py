from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,null=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    branch = models.CharField(max_length=50)
    cgpa = models.FloatField()
    skills = models.TextField()
    resume = models.FileField(upload_to='resumes/')


class Company(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    location = models.CharField(max_length=100)
    description = models.TextField()


class Job(models.Model):
    company = models.ForeignKey(Company,on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    eligibility_cgpa = models.FloatField()
    skills_required = models.TextField()
    deadline = models.DateField()


class Application(models.Model):
    student = models.ForeignKey(Student,on_delete=models.CASCADE)
    job = models.ForeignKey(Job,on_delete=models.CASCADE)
    status = models.CharField(max_length=50,default="Applied")
    interview_date = models.DateField(null=True,blank=True)
    result = models.CharField(max_length=50,null=True,blank=True)
    offer_letter = models.FileField(upload_to='offers/',null=True,blank=True)