from django.urls import path
from . import views

urlpatterns = [

path('',views.home),

path('student/',views.student_register),
path('login/',views.login_view),
path('logout/',views.logout_view),
path('dashboard/',views.dashboard),

path('company/',views.company_register),
path('job/',views.add_job),
path('jobs/',views.view_jobs),

path('apply/<int:id>/',views.apply_job),

path('applications/',views.applications),
path('shortlist/<int:id>/',views.shortlist),
path('schedule/<int:id>/',views.schedule),
path('result/<int:id>/',views.publish_result),

]